package com.adminportal.controller;

import java.util.ArrayList;
import java.util.List;

import com.adminportal.domain.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.adminportal.service.BookService;

@RestController
public class ResourceController {

	@Autowired
	private BookService bookService;
	
	@RequestMapping(value="/book/removeList", method=RequestMethod.POST)
	public String removeList(
			@RequestBody ArrayList<String> bookIdList, Model model
			){

		for (String id : bookIdList) {
			String bookId =id.substring(8);
			bookService.deleteById(Long.parseLong(bookId));
		}

		return "delete success";
	}
}


//	@RequestMapping(value="/oneBook/{id}")
//	public String remove(@PathVariable Long id, Model model
//	) {
//		bookService.deleteById(id);
//		List<Book> bookList = bookService.findAll();
//		model.addAttribute("bookList", bookList);
//
//		return "redirect:/book/bookList";