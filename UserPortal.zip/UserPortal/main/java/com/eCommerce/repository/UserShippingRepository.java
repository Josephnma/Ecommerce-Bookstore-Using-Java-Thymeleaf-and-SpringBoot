package com.eCommerce.repository;

import org.springframework.data.repository.CrudRepository;

import com.eCommerce.domain.UserShipping;

public interface UserShippingRepository extends CrudRepository<UserShipping, Long> {
	
	

}
